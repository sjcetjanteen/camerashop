<?php

require_once '../db.php';
$camera = $_POST['cam_name'];
$model = $_POST['cam_model'];
$price = $_POST['cam_price'];
$image = $_FILES['image']['name'];

// var_dump($_FILES);
// die;
if ($camera == "" && $model == "" && $price == "" && $image == "") {
    echo "please fill the required fields";
} else {


    $cam_insert = "INSERT INTO cam (cam_name,cam_model,cam_price,images)VALUES('$camera','$model','$price','$image')";
    $result = $conn->query($cam_insert);


    if ($result == true) {
        move_uploaded_file($_FILES['image']['tmp_name'], "uploads/" . $_FILES['image']['name']);
        header("location:camview.php");
    }
}
// var_dump($result);
// die;