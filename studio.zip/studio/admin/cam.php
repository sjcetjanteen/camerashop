<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<style>
    input{
        padding: 7px;
        margin: 10px;
        border-radius: 5px;
    }
    body{
        text-align: center;
        margin-top: 120px;
        background-color: bisque;
    }
    
</style>
<body>
    <h3>ADD CAMERAS</h3>
<form action="./addcam.php" method="post" enctype="multipart/form-data">
    <div>
        <label for="">Camera Name</label>
        <input type="text" name="cam_name" id="cam_name">
    </div>

    <div>
        <label for="">Camera Model</label>
        <input type="text" name="cam_model" id="cam_model">
    </div>

    <div>
        <label for="">Camera Price</label>
        <input type="number" name="cam_price" id="cam_price">
    </div>

    <div>
        <label for="">images</label>
        <input type="file" name="image" id="image">
    </div>

    <div>
        <input type="submit" value="submit">
    </div>
<br>
<a href="./camview.php">view items</a>
</form>
</body>
</html>