<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Cameras</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <style>
        /* General Reset and Body Styling */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Roboto', sans-serif;
        background-color:rgb(63, 43, 43);
            
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        h3 {
            margin-bottom: 20px;
            font-size: 1.8rem;
            color: #333;
            font-weight: 500;
        }

        /* Form Container */
        .form-container {
            background-color: #ffffff;
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 500px;
        }

        .form-container label {
            display: block;
            font-size: 1.1rem;
            margin-bottom: 5px;
            color: #555;
        }

        .form-container input[type="text"],
        .form-container input[type="number"],
        .form-container input[type="file"] {
            width: 100%;
            padding: 12px;
            margin-bottom: 15px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 1rem;
            outline: none;
            transition: all 0.3s ease;
        }

        .form-container input[type="text"]:focus,
        .form-container input[type="number"]:focus,
        .form-container input[type="file"]:focus {
            border-color: #007bff;
            box-shadow: 0 0 5px rgba(0, 123, 255, 0.5);
        }

        .form-container input[type="submit"] {
            background-color: #28a745;
            color: #fff;
            font-size: 1.1rem;
            padding: 12px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            width: 100%;
            transition: background-color 0.3s ease;
        }

        .form-container input[type="submit"]:hover {
            background-color: #218838;
        }

        .form-container a {
            display: block;
            margin-top: 20px;
            font-size: 1rem;
            color: #007bff;
            text-decoration: none;
            text-align: center;
            transition: color 0.3s ease;
        }

        .form-container a:hover {
            color: #0056b3;
        }
    </style>
</head>
<body>

    <div class="form-container">
        <h3>Add Cameras</h3>
        <form action="./addcam.php" method="post" enctype="multipart/form-data">
            <div>
                <label for="cam_name">Camera Name</label>
                <input type="text" name="cam_name" id="cam_name" placeholder="Enter camera name" required>
            </div>

            <div>
                <label for="cam_model">Camera Model</label>
                <input type="text" name="cam_model" id="cam_model" placeholder="Enter camera model" required>
            </div>

            <div>
                <label for="cam_price">Camera Price</label>
                <input type="number" name="cam_price" id="cam_price" placeholder="Enter camera price" required>
            </div>

            <div>
                <label for="image">Upload Image</label>
                <input type="file" name="image" id="image" required>
            </div>

            <div>
                <input type="submit" value="Submit">
            </div>
        </form>

        <a href="./camview.php">View Items</a>
    </div>

</body>
</html>
