<?php

require_once '../db.php';

$id = $_POST['cam_id'];

// var_dump($_POST);
// die;



$camera=$_POST['cam_name'];
$model=$_POST['cam_model'];
$price=$_POST['cam_price'];
$image=$_FILES['image']['name'];

// var_dump($_POST);
// die;
$update="UPDATE cam SET cam_name= '$camera', cam_model='$model' , cam_price='$price', images='$image' WHERE cam_id=".$id;
$result=$conn->query($update);
if($result==true){
    move_uploaded_file($_FILES['image']['tmp_name'], "uploads/" . $_FILES['image']['name']);
    header("location:cam.php");
}