<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="./styles.css">
</head>

<body>

</body>

</html>

<?php
require_once '../db.php';

$camview = "SELECT * FROM cam";
$result = $conn->query($camview);

echo "<div class='card-container'>";  // Wrapper for all cards
while ($row = $result->fetch_assoc()) {
    // Start a new card for each camera
    echo "<div class='card'>";
    // Card image first (on top)
    echo "<img src='uploads/" . $row['images'] . "' alt='Camera Image' style='width: 100px; height: 100px; display: block; margin: 0 auto; '>";
    // Card details (camera name, model, price)
    echo "<h2>" . $row['cam_name'] . "</h2>";
    echo "<p><strong>Model:</strong> " . $row['cam_model'] . "</p>";
    echo "<p><strong>Price:</strong> Rs : " . $row['cam_price'] . "</p>";
    echo "<div id='btn'>";
    echo "<a href='editcamera.php?id=" . $row['cam_id'] . "' class='edit-button'>edit</a>";

    echo "<a href='deletecamera.php?id=" . $row['cam_id'] . "' class='delete-button'>Delete</a>";
    // Close the card div
    echo "</div>";

    echo "</div>";
}
echo "</div>";  // Close the card container
?>

<br>
<div id="foot">
    <div>
        <a href="./cam.php">add more</a>
    </div>

    <div>
        <a href="../adminwelcome.php">go to home</a>
    </div>
</div>