<?php

require_once '../db.php';
$id=$_GET['id'];

// var_dump($_GET);
// die;

$sql_del="DELETE FROM cam WHERE cam_id=".$id;

$del=$conn->query($sql_del);
if($del==true){
    header("location:../adminwelcome.php");
}