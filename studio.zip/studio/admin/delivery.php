<?php

require_once '../db.php';




$id = $_GET['order_id'];

$orderid = "select * from order_table where order_id = '$id'";

$resu = $conn->query($orderid);

while ($rowww = $resu->fetch_assoc()) {

    $order = $rowww['order_id'];
   
    $user = $rowww['userid'];
    

}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delivery Boy Details</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        header {
            background-color: #2c3e50;
            color: white;
            text-align: center;
            padding: 20px;
        }

        .container {
            max-width: 900px;
            margin: 20px auto;
            padding: 20px;
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .delivery-boy {
            display: flex;
            flex-direction: column;
            align-items: center;
            padding: 20px;
            border: 1px solid #ddd;
            border-radius: 10px;
            background-color: #ecf0f1;
        }

        .delivery-boy h2 {
            margin-bottom: 10px;
            color: #2c3e50;
        }

        .delivery-boy p {
            font-size: 18px;
            color: #34495e;
            margin: 5px 0;
        }

        .btn {
            background-color: #27ae60;
            color: white;
            text-decoration: none;
            padding: 10px 20px;
            border-radius: 5px;
            font-weight: bold;
            margin-top: 20px;
            display: inline-block;
            text-align: center;
            transition: background-color 0.3s ease;
        }

        .btn:hover {
            background-color: #2ecc71;
        }

        footer {
            background-color: #2c3e50;
            color: white;
            text-align: center;
            padding: 10px;
            position: relative;
            bottom: 0;
            width: 100%;
        }
        a{
            color:black;
        }
    </style>
</head>

<body>

    <header>
        <h1>Delivery Boy Information</h1>
    </header>
    <form action="deliverysubmit.php" method="POST">
        <div class="container">
            <div class="delivery-boy">
                <h2>Delivery Boy Details</h2>
                <input type="hidden" name="order_id" value="<?php echo $order; ?>">
                <input type="hidden" name="user_id" value="<?php echo $user; ?>">
                <p id="d_name1" name="d_name"><strong>Name:</strong> Dom</p>
                <p id="d_phone1" name="d_phone"><strong>Phone Number:</strong> 9446758121</p>
                <button type="submit" class="btn">Connect Delivery Boy</button>
            </div>
        </div>
    </form>
    <footer>
        <p>&copy; INSHOT Delivery Service. All rights reserved.</p>

        <h2><a href="../adminwelcome.php">home page</a></h2>
    </footer>

</body>

</html>