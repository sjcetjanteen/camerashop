<?php

require_once '../db.php';
$oid=$_POST['order_id'] ;
$uid=$_POST['user_id'] ;
// var_dump($_POST);die;

$insert="INSERT INTO delivery(order_id,userid)VALUES('$oid',$uid)";
$ins=$conn->query($insert);
if($ins==true){
$update_status="UPDATE order_table SET shipping_status='Delivered' WHERE order_id=".$oid;
$res=$conn->query($update_status);
if($res==true){
    header("Location:userordersview.php"); 
    exit;
}
}


