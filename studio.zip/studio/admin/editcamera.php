<?php
require_once '../db.php';

$id = $_GET['id'] ?? null;
if ($id == null) {
    die("invalid request");
}
$sql_select = "SELECT * FROM cam WHERE cam_id=" . $id;
$res = $conn->query($sql_select);
while ($row = $res->fetch_assoc()) {



 ?>

    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Document</title>
    </head>
    <style>
        input {
            padding: 7px;
            margin: 10px;
            border-radius: 5px;
        }

        body {
            text-align: center;
            margin-top: 120px;
        }
    </style>

    <body>
        <h3>ADD CAMERAS</h3>
        <form action="./cameraupdate.php" method="post" enctype="multipart/form-data">
            <input type="hidden" name="cam_id" id="cam_id" value="<?= $row['cam_id'] ?>">

            <div>
                <label for="">Camera Name</label>
                <input type="text" name="cam_name" id="cam_name" value="<?= $row['cam_name'] ?>">
            </div>

            <div>
                <label for="">Camera Model</label>
                <input type="text" name="cam_model" id="cam_model" value="<?= $row['cam_model'] ?>">
            </div>

            <div>
                <label for="">Camera Price</label>
                <input type="number" name="cam_price" id="cam_price" value="<?= $row['cam_price'] ?>">
            </div>

            <div>
                <label for="">images</label>
                <input type="file" name="image" id="image" value="<?= $row['images'] ?>">
            </div>

            <div>
                <input type="submit" value="submit">
            </div>
            <br>
            <a href="./camview.php">view items</a>
        </form>

    <?php
}
    ?>
    </body>

    </html>