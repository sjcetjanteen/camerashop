<?php

require_once '../db.php';



$order_id=$_GET['id'];

$update_status="UPDATE order_table SET shipping_status='Shipped' WHERE order_id=".$order_id;
$res=$conn->query($update_status);
if($res==true){
    header("Location: delivery.php?order_id=" . $order_id); 
    exit;
}
?>
