<?php

require_once '../db.php';

$show="SELECT * FROM enquiry";

$res=$conn->query($show);
echo "<table border=1>";
echo"<th>Customer name</th><th>email</th><th>Customer enquiries</th>";
echo "<tr>";
while($row=$res->fetch_assoc()){
   echo "<td>".$row['name']."</td>";
   echo "<td>".$row['email']."</td>";
   echo "<td>".$row['message']."</td>";
echo "<tr>";
    
}
echo "</table>";

?>

<br>
<h2><a href="../adminwelcome.php">go back</a></h2>