<?php
require_once '../db.php';

$users="SELECT * FROM users ";
$res=$conn->query($users);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<style>
    th{
        background-color: gray;
        padding: 10px;
        width: 200px;
    }
    td{
        background-color: lightsalmon;
        padding: 5px;
    }
    .btn{
        background-color: red;
        color: white;
        margin-left: 70px;
        border: 1px solid black;
    }
    a{
        text-decoration: none;
    }

</style>
<body>
    <h2>USERS LIST</h2>
    <form action="" method="post">
        <table>
            <th>username</th>
            <th>useremail</th>
            <th>action</th>
            <tbody>
                <?php
while($row=$res->fetch_assoc()){
echo "<tr>";
   echo "<td>".$row['username']."</td>";
   echo "<td>".$row['useremail']."</td>";
   echo "<td><a href='removeuser.php?id=".$row['userid']."' class='btn' onclick='return deleteb()'>Remove</a></td>";
echo "<tr>";

}

                ?>

            </tbody>
        </table>
    </form>
    <a href="../adminwelcome.php">go back</a>
</body>
<script>
    function deleteb(){
        return confirm("are you want to remove this user")
    }
</script>
</html>