<?php
session_start();
require_once '../db.php';



// Query to get order, customer, and payment details
// $userview = "SELECT cam.cam_name ,cam.cam_model,cam.cam_price, users.username,users.useremail, address.addressname,address.phone, address.pincode, payment.card_num, payment.cvv FROM `order_table` INNER JOIN cam ON cam.cam_id = order_table.cam_id INNER JOIN users ON users.userid = order_table.userid INNER JOIN address ON address.userid = users.userid INNER JOIN payment ON payment.userid = users.userid";
$userview = "SELECT cam.cam_name ,cam.cam_model,cam.cam_price, users.username,users.useremail, address.addressname,address.phone, address.pincode, payment.card_num, payment.cvv,order_table.order_id,order_table.shipping_status FROM `order_table` INNER JOIN cam ON cam.cam_id = order_table.cam_id INNER JOIN users ON users.userid = order_table.userid INNER JOIN address ON address.userid = users.userid INNER JOIN payment ON payment.userid = users.userid;";
$res = $conn->query($userview);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Details</title>
    <style>
        /* Global Styles */
        body {
            font-family: 'Arial', sans-serif;
      background-color:rgb(63, 43, 43);
            
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
        }

        .card-container {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 20px;
            padding: 20px;
        }

        .card {
            background-color: #fff;
            border: 1px solid #ddd;
            border-radius: 10px;
            width: 300px;
            padding: 20px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease;
            margin-bottom: 20px;
        }

        .card:hover {
            transform: translateY(-5px);
        }

        .card h3 {
            margin-top: 0;
            font-size: 1.5em;
            color: #333;
        }

        .card p {
            font-size: 1em;
            color: #555;
            margin: 5px 0;
        }

        .card .label {
            font-weight: bold;
        }

        .back-link {
            display: block;
            margin-top: 30px;
            font-size: 1.1em;
            color: #007bff;
            text-decoration: none;
        }

        .back-link:hover {
            text-decoration: underline;
        }

        .card .action-button {
            display: inline-block;
            padding: 10px 20px;
            background-color: #28a745;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            font-weight: bold;
            margin-top: 20px;
            margin-left: 70px;
            text-align: center;
            transition: background-color 0.3s ease;
        }

        .card .action-button:hover {
            background-color: #218838;
        }

    </style>
</head>

<body>

    <h1>Order Details</h1>

    <div class="card-container">
        <?php
        while ($row = $res->fetch_assoc()) {
            // var_dump($row);
            // die;
            echo "<div class='card'>";
            echo "<h3>Order for " . $row['cam_name'] . "</h3>";
            echo "<p><span class='label'>Camera Model:</span> " . $row['cam_model'] . "</p>";

            echo "<p><span class='label'>Price:</span> Rs. " . number_format($row['cam_price']) . "</p>";

            echo "<p><span class='label'>Customer Name:</span> " . $row['username'] . "</p>";
            echo "<p><span class='label'>Customer email:</span> " . $row['useremail'] . "</p>";
            echo "<p><span class='label'>Address:</span> " . $row['addressname'] . "</p>";
            echo "<p><span class='label'>Pincode:</span> " . $row['pincode'] . "</p>";

            echo "<p><span class='label'>Card Number:</span> " . $row['card_num'] . "</p>";
            echo "<p><span class='label'>CVV:</span> " . $row['cvv'] . "</p>";
            echo "<p style='color:red'><span class='label'>shipping status:</span> " . $row['shipping_status'] . "</p>";

           
                echo "<a href='start_shipping.php?id=".$row['order_id']." ' class='action-button'>Start Shipping</a>";
            


            echo "</div>";
        }
        ?>
    </div>
 
    <a href="../adminwelcome.php" class="back-link">Go back</a>

</body>

</html>
