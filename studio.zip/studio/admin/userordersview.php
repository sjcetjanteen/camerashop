<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<style>
    th{
        background-color: gray;
        padding: 10px;
        width: 200px;
    }
    td{
        background-color: lightsalmon;
        padding: 5px;
    }
    #head{
        background-color: red;
    }
</style>
<body>
    
</body>
</html>
<?php
session_start();
require_once '../db.php';
// var_dump($_POST);
// die;
// $userid=$_SESSION['asus'];


$userview="SELECT cam.cam_name,cam.cam_price,users.username,address.addressname,address.pincode,payment.card_num,payment.cvv FROM `order_table` INNER JOIN cam ON cam.cam_id=order_table.cam_id INNER JOIN users ON users.userid=order_table.userid INNER JOIN address ON address.userid= users.userid INNER JOIN payment ON payment.userid=users.userid" ;
$res=$conn->query($userview);
echo "<table border=1>";
echo "<div id='head'>";
  
echo "<tr ><th colspan=2 style='background-color: silver;'>order details</th><th colspan=3 style='background-color: silver;' >Customer details</th><th colspan=2 style='background-color: silver;' >payment details</th></tr>";
echo "</div>";

echo "<tr><th>Camera</th><th>Price</th><th>Customer</th><th>Address</th><th>Pincode</th><th>Cardnum</th><th>cvv</th></tr>";

while($row=$res->fetch_assoc()){
echo "<tr>";

    
    echo "<td>".$row['cam_name'] ."</td>";
    echo "<td>".$row['cam_price'] ."</td>";
    echo "<td>".$row['username'] ."</td>";
    echo "<td>".$row['addressname'] ."</td>";
    echo "<td>".$row['pincode'] ."</td>";
    echo "<td>".$row['card_num'] ."</td>";
    echo "<td>".$row['cvv'] ."</td>";
echo "</tr>";

}
echo "</table>";

?>
<br>
<a href="../adminwelcome.php" >go back</a>

