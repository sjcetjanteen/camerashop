<?php

session_start();
require_once './db.php';
?>

<?php
//  echo $_SESSION['bolt'];
// var_dump($_SESSION);
// die;
 if($_SESSION['admin']==""){
   ?>
   <script>
    alert("please log in");
    window.location.href="login.php";
   </script>
<?php
 }
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<style>
    * {
        padding: 0;
        margin: 0;
    }

    #nav {
        background-color:rgb(63, 43, 43);
        height: 50px;
        display: flex;
        flex-direction: row;
        justify-content: space-between;
        font-size: 20px;
        align-items: center;
        padding: 3px;




    }
    h2 {
        color: bisque;
    }

    h1 {
        background-color: beige;
    }

    body {
        background-image: url(./bg.jpg);
        background-size: cover;
        background-repeat: no-repeat;
        background-position: center center;
        height: 100vh;
        margin: 0;
        
    }

    a:hover {
        color: black;
    }

    a {
        font-size: 25px;
        text-decoration: none;
        color: bisque;
    }

    

        
        p{
            font-family: cursive;
            text-align: center;
            padding: 20px;
            color: whitesmoke;
        }
</style>

<body>
    <nav>
        <div id="nav">
            <div>
                <a href="">Home</a>
            </div>
            <div>
                <a href="./admin/userordersview.php">user orders</a>
            </div>

            <div>
                <a href="./admin/cam.php">add cameras</a>
            </div>

            <div>
                <a href="./admin/userlist.php">users list</a>
            </div>
            
            <div>
                <a href="./admin/camview.php">cameras</a>
            </div>

            <div>
                <a href="./admin/userenquiry.php">Enquiries</a>
            </div>

            <div>
                <a href="./logout.php">logout</a>
            </div>
        </div>
    </nav>
    <h2>admin page</h2>
    <div>
        <p>"Capture every moment with precision and clarity. Visit our camera shop today!"
"From amateurs to pros, we’ve got the perfect camera for you. See the world through a different lens!"
"Picture-perfect moments are just a click away. Find your perfect camera here!"</p>
     </div>
    
    <h3><?php $_SESSION['admin'] ?></h3>
</body>

</html>