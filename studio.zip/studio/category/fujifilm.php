<?php

require_once '../db.php';

$display ="SELECT * FROM `cam`WHERE cam_name='fujifilm' ";

$res = $conn->query($display);
if ($res->num_rows == 0) {
  header("location:../userwelcome.php");
  }
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
</head>
<style>
    /* Global Styles */
    body {
      font-family: 'Arial', sans-serif;
      background-color:rgb(42, 43, 42);
      
      margin: 0;
      padding: 0;
      display: flex;
      justify-content: center;
      align-items: center;
      flex-wrap: wrap;
      gap: 20px;
      /* min-height: 100vh; */
    
    }

    /* Card Container Styles */
    .card-container {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(240px, 1fr));
      gap: 20px;
      padding: 20px;
      width: 100%;
      max-width: 1200px;
    }

    /* Individual Card Styles */
    .card {
      background-color: rgb(173, 176, 185);
      
      border-radius: 12px;
      box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
      overflow: hidden;
      transition: transform 0.3s ease-in-out;
      text-align: center;
      padding: 15px;
      margin-bottom: 20px;
    }

    .card:hover {
      transform: translateY(-10px);
    }

    /* Image Styles */
    .product-image {
      width: 100%;
      height: 180px;
      object-fit: cover;
      border-radius: 8px;
      margin-bottom: 15px;
    }

    #btn {
      display: flex;
      gap: 2px;
    }

    .buy-button {
      display: inline-block;
      padding: 8px 15px;
      background-color: rgb(73, 102, 196);
      color: white;
      text-decoration: none;
      border-radius: 5px;
      font-weight: bold;
      text-align: center;
      width: 48%;
      /* Adjust the width to keep buttons aligned */
    }

    /* Title and Price Styles */
    h2 {
      font-size: 1.5em;
      color: #333;
      margin: 10px 0;
      font-weight: 600;
    }

    p {
      font-size: 1em;
      color: #777;
      margin: 5px 0;
    }

    /* Action Button Styles */
    .card-action button {
      padding: 10px 20px;
      background-color: #007bff;
      color: white;
      border: none;
      border-radius: 5px;
      cursor: pointer;
      font-size: 1.1em;
      transition: background-color 0.3s ease;
      margin-top: 15px;
    }

    .card-action button:hover {
      background-color: #0056b3;
    }

    /* Responsive Design */
    @media (max-width: 768px) {
      .card-container {
        grid-template-columns: 1fr 1fr;
      }

      h2 {
        font-size: 1.3em;
      }
      
      .product-image {
        height: 150px;
      }
    }
    h1{
      text-align: center;
      color: #007bff;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }
  </style>

<body>
<h1>FUJIFILM</h1>
  <?php
  echo "<div class='card-container'>"; 
  while ($row = $res->fetch_assoc()) {
    echo "<div class='card'>";
    echo "<img src='../admin/uploads/" . $row['images'] . "' alt='Camera Image' style='width: 100px; height: 100px; display: block; margin: 0 auto; '>";
    echo "<h2>" . $row['cam_name'] . "</h2>";
    echo "<p><strong>Model:</strong> " . $row['cam_model'] . "</p>";
    echo "<p><strong>Price:</strong> Rs: " . number_format($row['cam_price']) . "</p>";
    echo "<a href='../user/buy.php?id=" . $row['cam_id'] . "' class='buy-button'>buy</a>";
   
    echo "</div>";
  }
  echo "</div>";
  ?>

</body>

</html>