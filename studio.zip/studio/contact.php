<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        /* Custom CSS for styling */
        body {
            /* background-color:rgb(182, 198, 214); */
        background-color:rgb(63, 43, 43);

        }
        .contact-container {
            padding: 60px 0;
        }
        .contact-info {
            background-color: #fff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        .contact-info h3 {
            margin-bottom: 20px;
            color: #007bff;
        }
        .contact-info p {
            color: #555;
        }
        .form-control {
            border-radius: 5px;
        }
        .btn-primary {
            border-radius: 5px;
            padding: 12px 25px;
        }
        .map {
            margin-top: 40px;
        }
        iframe {
            width: 100%;
            height: 350px;
            border: none;
        }
        .social-links a {
            margin-right: 15px;
            font-size: 18px;
            color: #007bff;
            text-decoration: none;
        }
        .social-links a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

    <!-- Contact Section -->
    <div class="container contact-container">
        <div class="row">
            <!-- Contact Info -->
            <div class="col-md-6 contact-info">
                <h3>Contact Information</h3>
                <p><strong>Address:</strong> Inshot wedding planners</p>
                <p><strong>Email:</strong> <a href="mailto:inshot@company.com">inshot@company.com</a></p>
                <p><strong>Phone:</strong> +91-9567689785</p>

                <!-- WhatsApp Link -->
                <div class="social-links">
                    <p><strong>Connect with us:</strong></p>
                    <a href="https://wa.me/919567689785" target="_blank">WhatsApp</a>
                </div>
            </div>

            <!-- Contact Form -->
            <div class="col-md-6">
                <div class="contact-info">
                    <h3>Get in Touch</h3>
                    <form action="./enquiry.php" method="post">
                        <div class="mb-3">
                            <label for="name" class="form-label">Name</label>
                            <input type="text" class="form-control" id="name" name="name" placeholder="Enter your name" required>
                        </div>
                        <div class="mb-3">
                            <label for="email" class="form-label">Email</label>
                            <input type="email" class="form-control" id="email" name="email" placeholder="Enter your email" required>
                        </div>
                        <div class="mb-3">
                            <label for="message" class="form-label">Message</label>
                            <textarea class="form-control" id="message" rows="4" name="message" placeholder="Write your message" required></textarea>
                        </div>
                        <button type="submit" class="btn btn-primary">Send Message</button>
                    </form>
                </div>
            </div>
        </div>

        <!-- Google Map -->
        <div class="map">
            <h3>Our Location</h3>
            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3916.0187916420657!2d76.62915551624525!3d9.72907547741142!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3b0615ee63f2c6b1%3A0x9098f77e32fa2e7b!2sKaduthuruthy%2C%20Kottayam%20District%2C%20Kerala%2C%20India!5e0!3m2!1sen!2sus!4v1605506124844!5m2!1sen!2sus" allowfullscreen="" loading="lazy"></iframe>
        </div>
    </div>

    <!-- Bootstrap JS and dependencies -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js"></script>

</body>
</html>
