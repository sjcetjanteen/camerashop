<?php

$localhost= "localhost";
$username="root";
$password="";
$database="camera";

$conn=new mysqli($localhost,$username,$password,$database);