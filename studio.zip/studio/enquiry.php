<?php  
require_once './db.php';



$name=$_POST['name'];
$email=$_POST['email'];
$message=$_POST['message'];

$enquiry="INSERT INTO enquiry(name,email,message)VALUES('$name','$email','$message')";
$enq=$conn->query($enquiry);
if($enq==true){
    header("location:index.php");
}