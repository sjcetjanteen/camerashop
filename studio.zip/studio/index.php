<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        * {
            padding: 0;
            margin: 0;
            box-sizing: border-box;
        }

        #nav {
            background-color: brown;
            height: 50px;
            display: flex;
            justify-content: space-between;
            font-size: 20px;
            align-items: center;
            padding: 3px 20px;
        }

        body {
            background-image: url(./bg.jpg);
            background-size: cover;
            background-repeat: no-repeat;
            background-position: center center;
            height: 100vh;
            margin: 0;
            font-family: Arial, sans-serif;
            color: #fff;
            display: flex;
            flex-direction: column;
        }

        h1 {
            background-color: beige;
            color: #333;
            text-align: center;
            margin: 20px 0;
            padding: 10px;
        }

        a {
            font-size: 25px;
            text-decoration: none;
            color: #fff;
            transition: color 0.3s ease, background-color 0.3s ease;
        }

        a:hover {
            color: black;
        }

        footer {
            background-color: brown;
            color: white;
            text-align: center;
            padding: 15px;
            font-size: 18px;
            position: relative;
            bottom: 0;
            width: 100%;
            margin-top: auto; /* Pushes footer to the bottom of the page */
        }

        footer p {
            margin: 0;
        }
        p{
            font-family: cursive;
            text-align: center;
            padding: 20px;
        }

    </style>
</head>

<body>
    <nav>
        <div id="nav">
            <div>
                <a href="#">Home</a>
            </div>
            <div>
                <a href="./contact.php">Contact</a>
            </div>
            <div>
                <a href="./login.php">Login</a>
            </div>
        </div>
    </nav>

    <!-- Footer -->
     <div>
        <p>"Capture every moment with precision and clarity. Visit our camera shop today!"
"From amateurs to pros, we’ve got the perfect camera for you. See the world through a different lens!"
"Picture-perfect moments are just a click away. Find your perfect camera here!"</p>
     </div>
    <footer>
        <p>&copy; 2024  Inshot Camera. All rights reserved.</p>
    </footer>
</body>

</html>
