<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        * {
            padding: 0;
            margin: 0;
            box-sizing: border-box;
        }

        #nav {
        background-color:rgb(63, 43, 43);
            
            height: 50px;
            display: flex;
            justify-content: space-between;
            font-size: 20px;
            align-items: center;
            padding: 3px 20px;
        }

        body {
            background-image: url(./bg.jpg);
            background-size: cover;
            background-repeat: no-repeat;
            background-position: center center;
            height: 100vh;
            margin: 0;
            font-family: Arial, sans-serif;
            color: #fff;
            display: flex;
            flex-direction: column;
        }

        h1 {
            background-color: beige;
            color: #333;
            text-align: center;
            margin: 20px 0;
            padding: 10px;
        }

        a {
            font-size: 25px;
            text-decoration: none;
            color: #fff;
            transition: color 0.3s ease, background-color 0.3s ease;
        }

        a:hover {
            color: black;
        }

        footer {
        background-color:rgb(63, 43, 43);
           
            color: white;
            text-align: center;
            padding: 15px;
            font-size: 18px;
            position: relative;
            bottom: 0;
            width: 100%;
            margin-top: auto;
        }

        footer p {
            margin: 0;
        }

        p {
            font-family: cursive;
            text-align: center;
            padding: 20px;
        }

        /* Logo Styling */
        #nav img {
            width: 30px; /* Adjust logo size */
            height: auto;
            margin-right: 10px; /* Space between logo and text */
            vertical-align: middle; /* Align logo vertically with text */
        }

        #nav a {
            display: flex;
            align-items: center;
            padding: 10px 15px;
        }

        /* Fix for logo text */
        #nav a:first-child {
            font-size: 26px; /* Increase logo text size */
        }

        /* Right-align links */
        #nav .right-links {
            display: flex;
            justify-content: flex-end;
            flex-grow: 1; /* Take up all available space */
        }

        .right-links a {
            margin-left: 20px; /* Space between navigation links */
        }

        #strong {
            color: gray;
            font-family: 'Lucida Sans', 'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', Geneva, Verdana, sans-serif;
        }

    </style>
</head>

<body>
    <nav>
        <div id="nav">
            <div>
                <a href="#"><strong id="strong">INSHOT </strong><img src="./logo.jpg" alt="logo"></a>
            </div>
            <div class="right-links">
                <a href="#">Home</a>
                <a href="./contact.php">Contact</a>
                <a href="./login.php">Login</a>
            </div>
        </div>
    </nav>

    <!-- Footer -->
    <div>
        <p>"Capture every moment with precision and clarity. Visit our camera shop today!"
            "From amateurs to pros, we’ve got the perfect camera for you. See the world through a different lens!"
            "Picture-perfect moments are just a click away. Find your perfect camera here!"</p>
    </div>
    <footer>
        <p>&copy; 2024 Inshot Camera. All rights reserved.</p>
    </footer>
</body>

</html>
