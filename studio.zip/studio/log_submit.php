<?php
require_once './db.php';
session_start();



// var_dump($_POST);
// die;

if (isset($_POST)) {
    $email = $_POST['email'];
    $password = $_POST['pwd'];

    $sqllogin="SELECT * FROM users WHERE useremail='$email' AND password='$password' ";
    $result=$conn->query($sqllogin);
    $row=$result->fetch_assoc();

    if($email==="admin@gmail.com" && $password==='admin'){
        $_SESSION['admin']=$email;
        
        // var_dump($_SESSION);
        // die;
        
        header("location:adminwelcome.php");

    }else if($row['useremail']==$email && $row['password']==$password){
        $_SESSION['bolt'] = $row['useremail'];
        $_SESSION['asus']= $row['userid'];
       

       
        header("location:userwelcome.php");

        
    }

   

}

