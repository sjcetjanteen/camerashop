<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<style>
    body{
        display: flex;
        justify-content: center;
        height: 80vh;
        align-items: center;
       background-image: url(./bg.jpg);
       background-size: cover;
            background-repeat: no-repeat;
            background-position: center center;
            height: 100vh;
            margin: 0;
            
            
           
        
   

    }
    h3{
        text-align: center;
    }
    form{
        
        border: 1px solid black;
        padding: 40px;
        background-color: grey;
    }
    label {
            display: block;
            margin-bottom: 5px;
            color: white;
        }

        input {
            width: 100%;
            padding: 10px;
            margin: 5px 0;
            border-radius: 5px;
            border: 1px solid #ccc;
        }
    button{
        background-color: green;
        height: 30px;
        width: 80px;
       margin-left: 50px;
       border-radius: 8px;

    }
    button:hover{
        background-color: lightgreen;
    }
    a:hover{
        color: black;
    }
</style>
<body>
    <form action="./log_submit.php" method="post">
        <h3>login page</h3>

        <div>
            <label for="">email</label>
            <input type="email" id="email" name="email">
        </div><br>

        <div>
            <label for="">password</label>
            <input type="password" id="pwd" name="pwd">
        </div>

        <div>
            <button type="submit">login</button>
        </div>
        <a href="./register.php">register here</a>
    </form>
</body>

</html>