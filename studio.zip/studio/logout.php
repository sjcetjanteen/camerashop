<?php
session_start();
require_once './db.php';
// var_dump($_SESSION);
// die;
if(isset($_SESSION['bolt'])){
    session_unset();
    session_destroy();
    header("location:index.php");
}else{
    $_SESSION['admin'];
    session_unset();
    session_destroy();
    header("location:index.php");


}