<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<style>
    * {
        padding: 0;
        margin: 0;
    }

    #nav {
        background-color: rgb(63, 43, 43);
        height: 50px;
        width: unset;
        width: 1337px;
        display: flex;
        flex-direction: row;
        justify-content: space-between;
        font-size: 20px;
        align-items: center;
        padding: 3px;
        /* width: 100%; */

    }

    a {

        text-decoration: none;
        color: rgb(121, 115, 115);
    }



    a:hover {
        color: black;
    }




    .dropdown {
        position: relative;
        display: inline-block;
    }

    .dropdown-content {
        display: none;
        position: absolute;
        background-color: #f1f1f1;
        min-width: 160px;
        box-shadow: 0px 8px 16px rgba(0, 0, 0, 0.2);
        z-index: 1;
    }

    .dropdown:hover .dropdown-content {
        display: block;
    }

    .dropdown-content a {
        color: black;
        padding: 12px 16px;
        text-decoration: none;
        display: block;
    }

    .dropdown-content a:hover {
        background-color: #ddd;
    }

    .dropdown-content a {
        font-size: 15px;
    }

    </style>

<body>
    <nav>
        <div id="nav">
            <div>
                <a href="">Home</a>
            </div>

            <div>
                <a href="./user/usercamview.php">Cameras</a>
            </div>

            
            <div class="dropdown">
                <a href="#" class="dropbtn">Categories</a>
                <div class="dropdown-content">
                    <a href="./category/sony.php">sony</a>
                    <a href="./category/nikon.php">nikon</a>
                    <a href="./category/canon.php">canon</a>
                    <a href="./category/fujifilm.php">FujiFilm</a>
                </div>
            </div>

            <div>
                <a href="./user/myorders.php">Orders</a>
            </div>

            <div>
                <a href="./logout.php">Logout</a>
            </div>
        </div>
    </nav>
</body>

</html>