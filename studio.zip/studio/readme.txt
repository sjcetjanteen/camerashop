tables
db:name--> camera

tables
1.address(id,addressname,city,state,pincode,phone,userid)

2.cam(cam_id,cam_name,cam_model,cam_price,images)

3.order_table(order_id,userid,cam_id)

4.payment(payid,card_num,expiry,cvv,userid)

5.users(userid,username,useremail,password)

admin
create this same email and pwd in the db through hardcoding

username:admin@gmail.com
pwd:admin