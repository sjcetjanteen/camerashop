<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="./style.css">
</head>
<style>
    body {
        display: flex;
        justify-content: center;
        height: 80vh;
        align-items: center;
        background-image: url(./bg.jpg);
       background-size: cover;
            background-repeat: no-repeat;
            background-position: center center;
            height: 100vh;
            margin: 0;
    }

    input,
    textarea {
        padding: 10px;
        border-radius: 8px;
    }

    form {
        background-color: grey;
        padding: 50px;
        border-radius: 8px;
        margin-top: 40px;

    }

    button {
        background-color: green;
        padding: 5px;
        margin-left: 100px;
        width: 100px;
        border-radius: 5px;

    }

    button:hover {
        background-color: lightgreen;

    }

    .main {
        display: flex;
        flex-direction: column;

    }

    label,
    input,
    textarea {
        width: 100%;
    }

    a:hover {
        color: black;
    }
</style>

<body>
    <form action="./regsubmit.php" method="post" onsubmit="return validate()">
        <div class="main">
            <h3>camera shop</h3>
            <div>
                <label for="">name</label>
                <input type="text" id="username" name="username">
            </div>
            <span class="error" id="nameerror"></span>
            <div>
                <label for="">Email</label>
                <input type="email" id="useremail" name="useremail">
            </div>
            <span class="error" id="emailerror"></span>


            <div>
                <label for="">Password</label>
                <input type="password" id="pwd" name="pwd">
            </div>
            <span class="error" id="pwderror"></span>


            <br>
            <div>
                <button type="submit">register</button>
            </div>
        </div>
        <a href="./login.php">already user</a>
    </form>
</body>

<script>
    function validate() {

        document.getElementById("nameerror").innerHTML = "";
        document.getElementById("emailerror").innerHTML = "";
        document.getElementById("pwderror").innerHTML = "";


        const name = document.getElementById("name").value;
        const email = document.getElementById("email").value;
        const pwd = document.getElementById("pwd").value;


        if (name === "") {
            document.getElementById("nameerror").innerHTML = "required name";
            return false;
        }
        if (email === "") {
            document.getElementById("emailerror").innerHTML = "email required ";
            return false;
        }
        if (password === "") {
            document.getElementById("pwderror").innerHTML = "password required ";
            return false;
        }



        return true;
    }
</script>

</html>