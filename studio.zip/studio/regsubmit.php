<?php

require_once './db.php';

$userid=$_POST['userid'];
$username=$_POST['username'];
$email=$_POST['useremail'];
$password=$_POST['pwd'];

$email_check = "SELECT * FROM users WHERE useremail='$email' ";
$res = $conn->query($email_check);
if ($res->num_rows > 0) {
    echo "email already exists";
} else {


    //user insert
    $sql_insert = "INSERT INTO users(username,useremail,password)VALUES('$username','$email','$password')";

    if ($conn->query($sql_insert) == true) {
        
        header("location:login.php");
    } else {
        echo "connection error";
    }
}

?>
<!-- <br>
<a href="./login.php">log in here</a> -->