<?php
// Optional: Process the form submission and save the data to the database or handle it accordingly
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
   
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shipping Address</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 20px;
        }

        .container {
            max-width: 600px;
            margin: 0 auto;
            background-color: #fff;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }

        h1 {
            text-align: center;
            color: #333;
            margin-bottom: 20px;
        }

        label {
            font-size: 14px;
            color: #555;
            margin-bottom: 5px;
            display: block;
        }

        input, textarea {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 16px;
        }

        textarea {
            resize: vertical;
        }

        button {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
            width: 100%;
        }

        button:hover {
            background-color: #45a049;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            font-size: 14px;
            color: #333;
        }

        .form-group input, .form-group textarea {
            width: 100%;
            padding: 8px;
            font-size: 14px;
        }
    </style>
</head>
<body>

    <div class="container">
        <h1>Shipping Address</h1>
        <form action="address_submit.php" method="POST">
            

            <div class="form-group">
                <label for="address">enter your Address</label>
                <textarea id="address" name="addressname" rows="3" required placeholder="Enter your address"></textarea>
            </div>

            <div class="form-group">
                <label for="city">City</label>
                <input type="text" id="city" name="city" required placeholder="Enter your city">
            </div>

            <div class="form-group">
                <label for="state">State</label>
                <input type="text" id="state" name="state" required placeholder="Enter your state">
            </div>

            <div class="form-group">
                <label for="postal_code">Pin Code</label>
                <input type="text" id="pincode" name="pincode" required placeholder="Enter your pin code">
            </div>

            <div class="form-group">
                <label for="phone">Phone Number</label>
                <input type="text" id="phone" name="phone" required placeholder="Enter your phone number">
            </div>

            <button type="submit">Submit</button>
        </form>
    </div>

</body>
</html>
