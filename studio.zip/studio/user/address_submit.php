<?php  
session_start();
require_once '../db.php';

// var_dump($_POST);
// die;

$userid=$_SESSION['asus'];
// $add_id=$_POST['address_id'];
$add_name=$_POST['addressname'];
$city=$_POST['city'];
$state=$_POST['state'];
$pincode=$_POST['pincode'];
$phone=$_POST['phone'];

$sql_ins="INSERT INTO address(addressname,city,state,pincode,phone,userid)
VALUES('$add_name','$city','$state','$pincode','$phone','$userid')";

$results=$conn->query($sql_ins);
if($results==true){
    header("location:payment.php");
}


