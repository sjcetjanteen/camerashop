<?php
session_start();
require_once '../db.php';
$cam_id=$_GET['id'];
$userid=$_SESSION['asus'];




$show_cam="INSERT INTO order_table(userid,cam_id)VALUES('$userid','$cam_id')";



$result=$conn->query($show_cam);
if($result==true){
    header("location:address.php");
}
// var_dump($_GET);
// die;