<?php
session_start();
require_once '../db.php';

// var_dump($_SESSION);
// die;
$userid = $_SESSION['asus'];

$userview = "SELECT order_table.order_id, cam.cam_name, cam.cam_price, users.useremail ,order_table.shipping_status
             FROM `order_table` 
             INNER JOIN cam ON cam.cam_id = order_table.cam_id 
             INNER JOIN users ON users.userid = order_table.userid 
             WHERE users.userid = " . $userid;

$res = $conn->query($userview);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Orders</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Roboto', sans-serif;
        }

        body {
            background-color:rgb(151, 104, 104);
           
            color: #333;
            line-height: 1.6;
            padding: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        table th, table td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        table th {
            background-color: #6a4c4c;
            color: white;
        }

        table tr:hover {
            background-color: #f1f1f1;
        }

        .remove-btn {
            background-color: #e74c3c;
            color: white;
            padding: 8px 16px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        .remove-btn:hover {
            background-color: #c0392b;
        }

        h1 {
            text-align: center;
            color: #6a4c4c;
            margin-bottom: 40px;
        }

        .container {
            max-width: 800px;
            margin: 0 auto;
        }
    </style>
</head>
<body>

    <div class="container">
        <h1>Your Orders</h1>

        <table>
            <thead>
                <tr>
                    <th>Order ID</th>
                    <th>Camera Name</th>
                    <th>Price</th>
                    <th>User Email</th>
                    <th>status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                while ($row = $res->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . $row['order_id'] . "</td>";
                    echo "<td>" . $row['cam_name'] . "</td>";
                    echo "<td>" . $row['cam_price'] . "</td>";
                    echo "<td>" . $row['useremail'] . "</td>";
                    echo "<td>" . $row['shipping_status'] . "</td>";
                    echo "<td><a href='removeorders.php?order_id=" . $row['order_id'] . "' class='remove-btn' onclick='return deleteb()'>Remove</a></td>";
                    echo "</tr>";
                }
                ?>
            </tbody>
        </table>
    </div>

</body>
<script>
    function deleteb(){
        return confirm("are you want to delete")
    }
</script>
</html>
