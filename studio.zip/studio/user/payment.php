<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Form</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            padding: 20px;
        }

        .container {
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            max-width: 500px;
            margin: 0 auto;
        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
        }

        label {
            font-size: 14px;
            margin-bottom: 5px;
            display: block;
        }

        input[type="text"],
        input[type="email"],
        input[type="number"],
        input[type="month"],
        input[type="password"],
        textarea {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 16px;
        }

        input[type="submit"] {
            background-color: #4CAF50;
            color: white;
            border: none;
            padding: 10px 0;
            /* Adjusted padding to match input fields */
            font-size: 16px;
            border-radius: 5px;
            cursor: pointer;
            width: 100%;
            /* Ensures the button is the same width as the input fields */
            display: block;
            /* Ensures it's treated like a block element */
        }

        input[type="submit"]:hover {
            background-color: #45a049;
        }

        .form-group {
            margin-bottom: 15px;
            text-align: center;
        }

        .form-group input {
            width: calc(50% - 10px);
            margin-right: 10px;
        }

        .form-group input:last-child {
            margin-right: 0;
        }

        .error {
            font-size: small;
            color: red;
            margin-left: 130px;
        }
    </style>
</head>

<body>
    <div class="container">
        <h2>Payment Information</h2>
        <form action="./payment_submit.php" method="POST" onsubmit="return cardnum(event)">



            <div class="form-group">
                <label for="card_number">Card Number</label>
                <input type="number" id="card_num" name="card_num">
            </div>
            <span class="error" id="cnum"></span>

            <div class="form-group">
                <label for="expiry_date">Expiration Date</label>
                <input type="date" id="expiry" name="expiry">
            </div>

            <div class="form-group">
                <label for="cvv">CVV (Security Code)</label>
                <input type="password" id="cvv" name="cvv">
            </div>
            <span class="error" id="cvverror"></span>


            <input type="submit" value="Submit Payment">
        </form>
    </div>
</body>
<script>
    function cardnum(event) {
        
        document.getElementById("cnum").innerHTML = "";
        document.getElementById("cvverror").innerHTML = "";
        const card_num = document.getElementById("card_num").value;
        const cvv = document.getElementById("cvv").value;

        if (card_num.length !== 16) {
            document.getElementById("cnum").innerHTML = "must be 16 digits"
            event.preventDefault()
            return false;
        }
        if (cvv.length !== 3) {
            document.getElementById("cvverror").innerHTML = "must be 3 digits"
            event.preventDefault()
            return false;
        }
        return true;

    }
</script>

</html>