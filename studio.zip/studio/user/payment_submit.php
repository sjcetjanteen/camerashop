<?php
session_start();
require_once '../db.php';

$userid=$_SESSION['asus'];



$cardnumber=$_POST['card_num'];
$expiry=$_POST['expiry'];
$cvv=$_POST['cvv'];

$in_payment="INSERT INTO payment(card_num,expiry,cvv,userid)VALUES('$cardnumber','$expiry','$cvv','$userid')";

$result=$conn->query($in_payment);
if($result==true){
    header("location:usercamview.php");
}

 
// var_dump($_POST);
// die;