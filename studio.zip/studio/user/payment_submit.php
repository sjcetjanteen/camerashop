<?php
session_start();
require_once '../db.php';

$userid = $_SESSION['asus'];
$cardnumber = $_POST['card_num'];
$expiry = $_POST['expiry'];
$cvv = $_POST['cvv'];


// $exp_date = DateTime::createFromFormat('d/m/Y', $expiry);

$date=date("Y-m-d");
$current_date =strtotime($date);
$ex=strtotime($expiry); 


if ($ex < $current_date) {
    
    ?>
    <script>alert("invalid")
        window.location.href="payment.php";
    </script>
    


    <?php
    
   
    
} else {

    $in_payment = "INSERT INTO payment(card_num,expiry,cvv,userid)VALUES('$cardnumber','$expiry','$cvv','$userid')";

    $result = $conn->query($in_payment);
    if ($result == true) {
        header("location:usercamview.php");
        exit;
    } else {
        echo "Error inserting payment data: " . $conn->error;
    }
}
 
// var_dump($_POST);
// die;