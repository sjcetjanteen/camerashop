<?php

require_once '../db.php';
$oid=$_GET['order_id'];

// var_dump($_GET);
// die;
$del_remove="DELETE FROM order_table where order_id=".$oid;
$result=$conn->query($del_remove);
if($result==true){
    echo "removed successfully";
}

?>

