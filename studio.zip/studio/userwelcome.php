<?php
session_start();
require_once './db.php';
?>

<?php
//  echo $_SESSION['bolt'];

 if($_SESSION['bolt']==""){



   ?>
   <script>
    alert("please log in");
    window.location.href="login.php";
   </script>
<?php
 }
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<style>
    * {
        padding: 0;
        margin: 0;
    }

    #nav {
        background-color: brown;
        height: 50px;
        display: flex;
        flex-direction: row;
        justify-content: space-between;
        font-size: 20px;
        align-items: center;
        padding: 3px;
    }

    h1 {
        background-color: beige;
    }

    h3 {
        color: bisque;
        text-align: right;
    }

    body {
        background-image: url(./bg.jpg);
        background-size: cover;
        background-repeat: no-repeat;
        background-position: center center;
        height: 100vh;
        margin: 0;
        
    }

    a:hover {
        color: black;
    }

    a {
        font-size: 25px;
        text-decoration: none;
    }

    /* Dropdown styles */
    .dropdown {
        position: relative;
        display: inline-block;
    }

    .dropdown-content {
        display: none;
        position: absolute;
        background-color: #f1f1f1;
        min-width: 160px;
        box-shadow: 0px 8px 16px rgba(0, 0, 0, 0.2);
        z-index: 1;
    }

    .dropdown:hover .dropdown-content {
        display: block;
    }

    .dropdown-content a {
        color: black;
        padding: 12px 16px;
        text-decoration: none;
        display: block;
    }

    .dropdown-content a:hover {
        background-color: #ddd;
    }
    .dropdown-content a{
       font-size: 15px; 
    }

    p{
        font-family: cursive;
        color: whitesmoke;
        margin-top: 20px;
        text-align: center;

    }
</style>

<body>
    <nav>
        <div id="nav">
            <div>
                <a href="">Home</a>
            </div>
           
            <div>
                <a href="./user/usercamview.php">Cameras</a>
            </div>

            <!-- Dropdown Menu for Categories -->
            <div class="dropdown">
                <a href="#" class="dropbtn">Categories</a>
                <div class="dropdown-content">
                    <a href="./category/sony.php">sony</a>
                    <a href="./category/nikon.php">nikon</a>
                    <a href="./category/canon.php">canon</a>
                    <a href="./category/fujifilm.php">FujiFilm</a>
                </div>
            </div>

            <div>
                <a href="./user/myorders.php">Orders</a>
            </div>

            <div>
                <a href="./logout.php">Logout</a>
            </div>
        </div>
    </nav>
    <p>
    "Capture every moment with precision and clarity. 📸 Visit our camera shop today!"
"From amateurs to pros, we’ve got the perfect camera for you. See the world through a different lens!"
"Picture-perfect moments are just a click away. Find your perfect camera here!"
"Ready to level up your photography? Our latest cameras are waiting for you."
"Capture memories that last a lifetime. Visit our camera shop for top-quality gear."
    </p>
    
   
    <h3><?php echo $_SESSION['bolt']; ?></h3>
</body>

</html>
